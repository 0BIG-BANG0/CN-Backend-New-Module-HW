const app = require("./index");
app.listen(5000, () => {
  console.log("server is listening at 5000");
});
