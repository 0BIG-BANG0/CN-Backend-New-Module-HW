const employess = [
  {
    emp_id: "101A",
    name: "john",
    company: "CN",
  },
  {
    emp_id: "102A",
    name: "doe",
    company: "CN",
  },
  {
    emp_id: "103A",
    name: "doe",
    company: "CN",
  },
  {
    emp_id: "104A",
    name: "echo",
    company: "CN",
  },
  {
    emp_id: "105A",
    name: "vivi",
    company: "CN",
  },
];

export const allEmployees = () => {
  return employess;
};
