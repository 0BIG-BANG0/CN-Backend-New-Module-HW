// app.js - our main application file
// import { sum, mean } from './math.mjs';
// const math = require("./math.mjs");

import { sum, mean } from './math.mjs';
const nums = [1, 2, 3, 4, 5];
console.log(`The sum is ${sum(nums)}`);
console.log(`The mean is ${mean(nums)}`);


